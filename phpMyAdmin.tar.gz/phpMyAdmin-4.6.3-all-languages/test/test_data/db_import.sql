
--
-- Table structure for table `test_table`
--

CREATE TABLE IF NOT EXISTS `test_table` (
  `val` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
