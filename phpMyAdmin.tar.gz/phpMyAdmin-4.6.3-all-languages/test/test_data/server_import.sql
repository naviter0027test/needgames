--
-- Database: `test_import1`
--
CREATE DATABASE IF NOT EXISTS `test_import1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
--
-- Database: `test_import1`
--
CREATE DATABASE IF NOT EXISTS `test_import2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;

